package operador;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class realizarPedido {
    private JTextArea textArea1;
    private JButton agregarButton;
    private JTextField textField2;
    private JTextArea textArea2;
    private JPanel jpanel1;
    private JButton buscarButton;
    private JButton mostrarProductosButton;
    private JTextField textField1;
    private JTextArea textArea3;
    private JTextField textField3;
    private JButton limpiarButton;
    private JButton realizarPedidoButton;
    private JTextField textField4;
    private JButton mostrarMasVendidosButton;
    private JButton cerrarButton;
    private double totalAcumulado = 0.0;
    private Node<ProductoPedido> productosAgregados = null;

    private JPanel panel12;

    public JPanel getPanel() {
        return jpanel1;
    }
    public JPanel getPanel12() {
        return panel12;
    }

    public realizarPedido() {
        cargarProductosDesdeBaseDeDatos();

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarProductos();
            }
        });

        mostrarProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cargarProductosDesdeBaseDeDatos();
            }
        });

        agregarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarProductoAPedido();
            }
        });

        limpiarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarTextArea3();
            }
        });

        realizarPedidoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                realizarPedido();
            }
        });

        mostrarMasVendidosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarProductosMasPedidos();
            }
        });


        cerrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Window window = SwingUtilities.getWindowAncestor(cerrarButton);

                if (window != null) {
                    window.dispose();
                }
            }
        });
    }

    private void cargarProductosDesdeBaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                String consulta = "SELECT idcursos, nombre_curso, valor_curso FROM cursos";
                PreparedStatement ps = conexion.prepareStatement(consulta);
                ResultSet rs = ps.executeQuery();

                textArea2.setText("");

                while (rs.next()) {
                    int idcursos = rs.getInt("idcursos");
                    String nombre_curso = rs.getString("nombre_curso");
                    double valor_curso = rs.getDouble("valor_curso");
                    textArea2.append(idcursos + ": " + nombre_curso + ": $" + valor_curso + "\n");
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al cargar cursos desde la base de datos: " + e.getMessage());
            }
        }
    }

    private void buscarProductos() {
        String textoBuscado = textField2.getText();

        if (textoBuscado.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese un texto para buscar.");
            return;
        }

        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                String consulta = "SELECT idcursos, nombre_curso, valor_curso FROM cursos " +
                        "WHERE nombre_curso LIKE ?";
                PreparedStatement ps = conexion.prepareStatement(consulta);
                ps.setString(1, "%" + textoBuscado + "%");

                ResultSet rs = ps.executeQuery();

                textArea2.setText("");

                while (rs.next()) {
                    int idcursos = rs.getInt("idcursos");
                    String nombre_curso = rs.getString("nombre_curso");
                    double valor_curso = rs.getDouble("valor_producto");
                    textArea2.append(idcursos + ": " + nombre_curso + ": $" + valor_curso + "\n");
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al buscar curso en la base de datos: " + e.getMessage());
            }
        }
    }

    private void agregarProductoAPedido() {
        String curso = textField1.getText();
        String cantidadText = textField3.getText();

        if (curso.isEmpty() || cantidadText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
            return;
        }

        int cantidad = Integer.parseInt(cantidadText);
        double valorProducto = buscarValorProducto(curso);

        if (valorProducto == -1.0) {
            JOptionPane.showMessageDialog(null, "Curso no encontrado en la base de datos.");
            return;
        }

        double totalProducto = valorProducto * cantidad;

        ProductoPedido productoPedido = new ProductoPedido(curso, cantidad, totalProducto);
        productosAgregados = insertarNodo(productosAgregados, productoPedido);
        totalAcumulado += totalProducto;

        textArea3.setText("");

        Node<ProductoPedido> current = productosAgregados;
        while (current != null) {
            ProductoPedido pedido = current.data;
            textArea3.append("Curso: " + pedido.getNombre() +
                    ", Cantidad: " + pedido.getCantidad() +
                    ", Total: $" + pedido.getTotal() + "\n");
            current = current.next;
        }

        textArea3.append("Total acumulado: $" + totalAcumulado + "\n");
    }

    private Node<ProductoPedido> insertarNodo(Node<ProductoPedido> cabeza, ProductoPedido datos) {
        if (cabeza == null) {
            return new Node<>(datos);
        } else {
            Node<ProductoPedido> actual = cabeza;
            while (actual.next != null) {
                actual = actual.next;
            }
            actual.next = new Node<>(datos);
            return cabeza;
        }
    }

    private double buscarValorProducto(String nombreProducto) {
        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                String consulta = "SELECT valor_curso FROM cursos WHERE nombre_curso = ?";
                PreparedStatement ps = conexion.prepareStatement(consulta);
                ps.setString(1, nombreProducto);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    double valor = rs.getDouble("valor_curso");
                    conexion.close();
                    return valor;
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al buscar curso en la base de datos: " + e.getMessage());
            }
        }

        return -1.0; // Retorna -1.0 si el producto no se encontró en la base de datos
    }

    private void realizarPedido() {
        String nombreCliente = textField4.getText();
        String direccionCliente = "Dirección de ejemplo";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String fechaActual = sdf.format(new Date());

        if (nombreCliente.isEmpty() || productosAgregados == null) {
            JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos y agregue cursos.");
            return;
        }

        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                int idCliente = insertarCliente(conexion, nombreCliente, direccionCliente);

                if (idCliente == -1) {
                    JOptionPane.showMessageDialog(null, "Error al insertar/buscar el estudiante.");
                    return;
                }

                Node<ProductoPedido> current = productosAgregados;
                while (current != null) {
                    String nombreProducto = current.data.getNombre();
                    double totalProducto = current.data.getTotal();
                    int cantidad = current.data.getCantidad();

                    int idProducto = obtenerIdProducto(conexion, nombreProducto);

                    if (idProducto == -1) {
                        JOptionPane.showMessageDialog(null, "Error al obtener el ID del curso.");
                        return;
                    }

                    if (!insertarPedido(conexion, idProducto, idCliente, cantidad, totalProducto, fechaActual)) {
                        JOptionPane.showMessageDialog(null, "Error al insertar el curso pedido.");
                        return;
                    }

                    current = current.next;
                }

                JOptionPane.showMessageDialog(null, "Curso pedido realizado con éxito.");

                textField4.setText("");
                limpiarTextArea3();
            } catch (SQLException e) {
                System.err.println("Error al realizar el curso pedido: " + e.getMessage());
            } finally {
                try {
                    conexion.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private int insertarCliente(Connection conexion, String nombreCliente, String direccionCliente) throws SQLException {
        String consulta = "SELECT idestudiantes FROM estudiantes WHERE nombre = ?";
        PreparedStatement ps = conexion.prepareStatement(consulta);
        ps.setString(1, nombreCliente);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getInt("idestudiantes");
        } else {
            String insercion = "INSERT INTO estudiantes (nombre, direccion) VALUES (?, ?)";
            PreparedStatement psInsercion = conexion.prepareStatement(insercion, PreparedStatement.RETURN_GENERATED_KEYS);
            psInsercion.setString(1, nombreCliente);
            psInsercion.setString(2, direccionCliente);

            int filasAfectadas = psInsercion.executeUpdate();

            if (filasAfectadas > 0) {
                ResultSet generatedKeys = psInsercion.getGeneratedKeys();
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(1);
                }
            }
        }

        return -1;
    }

    private int obtenerIdProducto(Connection conexion, String nombreProducto) throws SQLException {
        String consulta = "SELECT idcursos FROM cursos WHERE nombre_curso = ?";
        PreparedStatement ps = conexion.prepareStatement(consulta);
        ps.setString(1, nombreProducto);
        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            return rs.getInt("idcursos");
        } else {
            return -1; // Producto no encontrado
        }
    }

    private boolean insertarPedido(Connection conexion, int idProducto, int idCliente, int cantidad, double totalProducto, String fecha) throws SQLException {
        String consulta = "INSERT INTO cursos_pedidos (idcursos, idestudiantes, cantidad, Fecha, total) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement ps = conexion.prepareStatement(consulta);
        ps.setInt(1, idProducto);
        ps.setInt(2, idCliente);
        ps.setInt(3, cantidad);
        ps.setString(4, fecha);
        ps.setDouble(5, totalProducto);

        int filasAfectadas = ps.executeUpdate();

        return filasAfectadas > 0;
    }

    private void limpiarTextArea3() {
        textArea3.setText("");
        productosAgregados = null;
        totalAcumulado = 0.0;
    }
    private void abrirVistaBuscarNumero() {
        Window window = SwingUtilities.windowForComponent(panel12);

        if (window instanceof JFrame) {
            ((JFrame) window).dispose();
        }

        buscarNumero buscarNumeroView = new buscarNumero();
        JFrame frame = new JFrame("Vista de Búsqueda de Número");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setContentPane(buscarNumeroView.getPanel());
        frame.pack();
        frame.setSize(800, 400);
        frame.setVisible(true);
    }

    private void mostrarProductosMasPedidos() {
        String nombreCliente = textField4.getText();

        if (nombreCliente.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Por favor, ingrese el nombre del estudiante.");
            return;
        }

        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                String consulta = "SELECT p.nombre_curso, SUM(pd.cantidad) AS total_cantidad " +
                        "FROM cursos_pedidos AS pd " +
                        "JOIN cursos AS p ON pd.idcursos = p.idcursos " +
                        "JOIN estudiantes AS c ON pd.idestudiantes = c.idestudiantes " +
                        "WHERE c.nombre = ? " +
                        "GROUP BY p.nombre_curso " +
                        "ORDER BY total_cantidad DESC";

                PreparedStatement ps = conexion.prepareStatement(consulta);
                ps.setString(1, nombreCliente);
                ResultSet rs = ps.executeQuery();

                textArea1.setText(""); // Limpiar el textArea1

                while (rs.next()) {
                    String nombreProducto = rs.getString("nombre_producto");
                    int totalCantidad = rs.getInt("total_cantidad");
                    textArea1.append(nombreProducto + ": Cantidad Total: " + totalCantidad + "\n");
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al obtener los cursos más pedidos: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new realizarPedido();
            }
        });
    }

    private class ProductoPedido {
        private String nombre;
        private int cantidad;
        private double total;

        public ProductoPedido(String nombre, int cantidad, double total) {
            this.nombre = nombre;
            this.cantidad = cantidad;
            this.total = total;
        }

        public String getNombre() {
            return nombre;
        }

        public int getCantidad() {
            return cantidad;
        }

        public double getTotal() {
            return total;
        }
    }

    private static class Node<T> {
        T data;
        Node<T> next;

        public Node(T data) {
            this.data = data;
            this.next = null;
        }
    }
}
