package operador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import databaseConexion.dbConexion;

public class registroUsuario {
    private JTextField telefonoText;
    private JTextField idText;
    private JTextField nombreText;
    private JTextField apellidoText;
    private JTextField tipoEstudianteText;
    private JTextField fechaDeCitaText;
    private JTextField ciudadText;
    private JTextField direccionText;
    private JButton registrarClienteButton;
    private JPanel panelUsuario;
    private JButton cerrarPaginaButton;

    public registroUsuario() {
        registrarClienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idText.getText());
                String nombre = nombreText.getText();
                String numero = telefonoText.getText();
                String apellido = apellidoText.getText();
                String direccion = direccionText.getText();
                String tipo = tipoEstudianteText.getText();
                String ciudad = ciudadText.getText();
                String fecha = fechaDeCitaText.getText();

                Connection con = dbConexion.obtenerConexion();

                if (con != null) {
                    try {
                        String sql = "INSERT INTO estudiantes (idestudiantes, telefono, nombre, apellido, tipo_estudiante, fecha_de_cita, ciudad, direccion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        PreparedStatement statement = con.prepareStatement(sql);
                        statement.setString(1, String.valueOf(id));
                        statement.setString(2, numero);
                        statement.setString(3, nombre);
                        statement.setString(4, apellido);
                        statement.setString(5, tipo);
                        statement.setString(6, fecha);
                        statement.setString(7, ciudad);
                        statement.setString(8,direccion);

                        statement.executeUpdate();

                        idText.setText("");
                        telefonoText.setText("");
                        nombreText.setText("");
                        apellidoText.setText("");
                        tipoEstudianteText.setText("");
                        fechaDeCitaText.setText("");
                        ciudadText.setText("");
                        direccionText.setText("");

                        JOptionPane.showMessageDialog(null, "Estudiante registrado con éxito");

                        abrirVistaRealizarPedido();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error al registrar el estudiante: " + ex.getMessage());
                    } finally {
                        try {
                            con.close();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        });
        cerrarPaginaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Window window = SwingUtilities.getWindowAncestor(cerrarPaginaButton);

                if (window != null) {
                    ((Window) window).dispose();
                }
            }
        });

    }

    public JPanel getPanelUsuario() {
        return panelUsuario;
    }

    private void abrirVistaRealizarPedido() {
        JFrame currentFrame = (JFrame) SwingUtilities.getRoot(panelUsuario);

        if (currentFrame != null) {
            currentFrame.dispose();

            realizarPedido realizarPedidoView = new realizarPedido();
            JFrame frame = new JFrame("Realizar curso pedido");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setContentPane(realizarPedidoView.getPanel());
            frame.pack();
            frame.setSize(800, 400);
            frame.setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Registro de Usuario");
                registroUsuario registroUsuarioView = new registroUsuario();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setContentPane(registroUsuarioView.getPanelUsuario());
                frame.pack();
                frame.setSize(800, 400);
                frame.setVisible(true);
            }
        });
    }
}
