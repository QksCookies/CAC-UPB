package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class Estudiantes {
    private JTextField idText;
    private JTextField nombreText;
    private JTextField apellidoText;
    private JTextField tipoText;
    private JTextField fechadeCitaText;
    private JTextField ciudadEstudianteText;
    private JTextField direccionText;
    private JTextField telefonoText;
    private JButton guardarCambiosButton;
    private JButton eliminarClienteButton;
    private JButton addClienteNuevoButton;
    private JTable estudiantesTable;
    private JPanel mainPanel;



    public Estudiantes() {
        cargarDatosEnJTable();


        estudiantesTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = estudiantesTable.getSelectedRow();
                if (selectedRow >= 0) {
                    Object idEstudiante = estudiantesTable.getValueAt(selectedRow, 0);
                    Object nombreEstudiante = estudiantesTable.getValueAt(selectedRow, 1);
                    Object apellidoEstudiante = estudiantesTable.getValueAt(selectedRow, 2);
                    Object tipoEstudiante = estudiantesTable.getValueAt(selectedRow, 3);
                    Object fechadeCita = estudiantesTable.getValueAt(selectedRow, 4);
                    Object ciudadEstudiante = estudiantesTable.getValueAt(selectedRow, 5);
                    Object direccionEstudiante = estudiantesTable.getValueAt(selectedRow, 6);
                    Object telefonoCliente = estudiantesTable.getValueAt(selectedRow, 7);

                    idText.setText(idEstudiante.toString());
                    nombreText.setText(nombreEstudiante.toString());
                    apellidoText.setText(apellidoEstudiante.toString());
                    tipoText.setText(tipoEstudiante.toString());
                    fechadeCitaText.setText(fechadeCita.toString());
                    ciudadEstudianteText.setText(ciudadEstudiante.toString());
                    direccionText.setText(direccionEstudiante.toString());
                    telefonoText.setText(telefonoCliente.toString());
                }
            }
        });

        guardarCambiosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCambiosEnBaseDeDatos();
            }
        });

        eliminarClienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarEstudianteSeleccionado();
            }
        });

        addClienteNuevoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Crear una instancia de la clase crearCliente
                CrearEstudiantes crearClienteView = new CrearEstudiantes();

                // Crear un JFrame para mostrar la vista de crearCliente
                JFrame crearClienteFrame = new JFrame("Crear Cliente");
                crearClienteFrame.setContentPane(crearClienteView.getPanel());
                crearClienteFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                crearClienteFrame.pack();
                crearClienteFrame.setVisible(true);
            }
        });




    }

    public void cargarDatosEnJTable() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("Tipo");
        modelo.addColumn("Fecha");
        modelo.addColumn("Ciudad");
        modelo.addColumn("Direccion");
        modelo.addColumn("Teléfono");

        try {
            Statement statement = conexion.createStatement();
            String query = "SELECT * FROM estudiantes";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                modelo.addRow(new Object[] {
                        resultSet.getInt("idestudiantes"),
                        resultSet.getString("telefono"),
                        resultSet.getString("nombre"),
                        resultSet.getString("apellido"),
                        resultSet.getString("tipo_estudiante"),
                        resultSet.getString("fecha_de_cita"),
                        resultSet.getString("ciudad"),
                        resultSet.getString("direccion"),
                });
            }

            estudiantesTable.setModel(modelo);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void guardarCambiosEnBaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int idEstudiantes = Integer.parseInt(idText.getText());
            String nuevoNombreEstudiante = nombreText.getText();
            String nuevoApellidoEstudiante = apellidoText.getText();
            String nuevoTipoEstudiante = tipoText.getText();
            String nuevaDireccionEstudiante = fechadeCitaText.getText();
            String nuevoBarrioEstudiante = ciudadEstudianteText.getText();
            String nuevoMunicipioEstudiante = direccionText.getText();
            String nuevoTelefonoEstudiante = telefonoText.getText();

            Statement statement = conexion.createStatement();
            String updateQuery = "UPDATE estudiantes SET nombre = '" + nuevoNombreEstudiante + "', apellido = '" + nuevoApellidoEstudiante + "', tipo_estudiante = '" + nuevoTipoEstudiante + "', direccion = '" + nuevaDireccionEstudiante + "', barrio = '" + nuevoBarrioEstudiante + "', municipio = '" + nuevoMunicipioEstudiante + "', telefono = '" + nuevoTelefonoEstudiante + "' WHERE idestudiantes = " + idEstudiantes;
            int rowsUpdated = statement.executeUpdate(updateQuery);

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Cambios guardados exitosamente.");
                cargarDatosEnJTable();
            } else {
                JOptionPane.showMessageDialog(null, "No se pudieron guardar los cambios.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void eliminarEstudianteSeleccionado() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int selectedRow = estudiantesTable.getSelectedRow();
            if (selectedRow >= 0) {
                int idEstudiantes = (int) estudiantesTable.getValueAt(selectedRow, 0);

                int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de que deseas eliminar este estudiante?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    Statement statement = conexion.createStatement();
                    String deleteQuery = "DELETE FROM estudiantes WHERE idestudiantes = " + idEstudiantes;
                    int rowsDeleted = statement.executeUpdate(deleteQuery);

                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(null, "Estudiante eliminado exitosamente.");
                        cargarDatosEnJTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar el estudiante.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Container getPanel() {
        return mainPanel;
    }
}
