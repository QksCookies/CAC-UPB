package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CrearEstudiantes {
    private JButton addEstudiantesButton;
    private JTextField telefonoText;
    private JTextField nombreText;
    private JTextField apellidoText;
    private JTextField tipoEstudianteText;
    private JTextField fechaDeCitaText;
    private JTextField ciudadText;
    private JTextField direccionText;
    private JPanel mainPanel;

    public CrearEstudiantes() {
        this.mainPanel = mainPanel;
        addEstudiantesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addEstudiantesABaseDeDatos();
            }
        });
    }

    public void addEstudiantesABaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int telefono = Integer.parseInt(telefonoText.getText());
            String nombre = nombreText.getText();
            String apellido = apellidoText.getText();
            String tipoEstudiante = tipoEstudianteText.getText();
            String fechaDeCita = fechaDeCitaText.getText();
            String ciudad = ciudadText.getText();
            String direccion = direccionText.getText();

            Statement statement = conexion.createStatement();
            String insertQuery = "INSERT INTO estudiantes (telefono, nombre, apellido, tipo_estudiante, fecha_de_cita, ciudad, direccion) " +
                    "VALUES ('" + telefono + "', '" + nombre + "', '" + apellido + "', '" + tipoEstudiante + "', '" + fechaDeCita + "', '" + ciudad + "', '" + direccion + "')";
            int rowsInserted = statement.executeUpdate(insertQuery);

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Estudiante añadido exitosamente.");

                telefonoText.setText("");
                nombreText.setText("");
                apellidoText.setText("");
                tipoEstudianteText.setText("");
                fechaDeCitaText.setText("");
                ciudadText.setText("");
                direccionText.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo añadir el estudiante.");
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Container getPanel() {
        return mainPanel;
    }
}
