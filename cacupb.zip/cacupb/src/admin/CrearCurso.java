package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CrearCurso {
    private JTextField nombreText;
    private JTextField valorText;
    private JButton addCursoButton;
    private JPanel mainPanel;

    public CrearCurso() {
        addCursoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addCursoABaseDeDatos();
            }
        });
    }

    public void addCursoABaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            String nombre = nombreText.getText();
            double valor = Double.parseDouble(valorText.getText());

            Statement statement = conexion.createStatement();
            String insertQuery = "INSERT INTO cursos (nombre_curso, valor_curso) " +
                    "VALUES ('" + nombre + "', " + valor + ")";
            int rowsInserted = statement.executeUpdate(insertQuery);

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Curso añadido exitosamente.");
                // Puedes limpiar los campos de texto después de añadir el producto si lo deseas.
                nombreText.setText("");
                valorText.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo añadir el curso.");
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Container getPanel() {
        return mainPanel;
    }
}
