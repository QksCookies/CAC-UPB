package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Cursos {
    private JTextField idText;
    private JTextField nombreText;
    private JTextField valorText;
    private JTable tablaCursos;
    private JPanel mainPanel;
    private JButton guardarCambiosButton;
    private JButton eliminarProductoButton;
    private JButton addProductoButton;

    public Cursos() {
        cargarDatosEnJTable();

        tablaCursos.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int selectedRow = tablaCursos.getSelectedRow();
                if (selectedRow >= 0) {
                    Object idCurso = tablaCursos.getValueAt(selectedRow, 0);
                    Object nombreCurso = tablaCursos.getValueAt(selectedRow, 1);
                    Object valorCurso = tablaCursos.getValueAt(selectedRow, 2);

                    idText.setText(idCurso.toString());
                    nombreText.setText(nombreCurso.toString());
                    valorText.setText(valorCurso.toString());
                }
            }
        });

        guardarCambiosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                guardarCambiosEnBaseDeDatos();
            }
        });

        eliminarProductoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarCursoSeleccionado();
            }
        });

        addProductoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CrearCurso crearProductoView = new CrearCurso();
                JFrame frame = new JFrame("Añadir Usuario");
                frame.setContentPane(crearProductoView.getPanel());
                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frame.pack();
                frame.setVisible(true);
            }
        });


    }

    public void cargarDatosEnJTable() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre de Curso");
        modelo.addColumn("Valor de Curso");

        try {
            Statement statement = conexion.createStatement();
            String query = "SELECT * FROM cursos";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                modelo.addRow(new Object[] {
                        resultSet.getInt("idcursos"),
                        resultSet.getString("nombre_curso"),
                        resultSet.getDouble("valor_curso")
                });
            }

            tablaCursos.setModel(modelo);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void guardarCambiosEnBaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int idCurso = Integer.parseInt(idText.getText());
            String nuevoNombreCurso = nombreText.getText();
            double nuevoValorCurso = Double.parseDouble(valorText.getText());

            Statement statement = conexion.createStatement();
            String updateQuery = "UPDATE cursos SET nombre_curso = '" + nuevoNombreCurso + "', valor_curso = " + nuevoValorCurso + " WHERE idcursos = " + idCurso;
            int rowsUpdated = statement.executeUpdate(updateQuery);

            if (rowsUpdated > 0) {
                JOptionPane.showMessageDialog(null, "Cambios guardados exitosamente.");
                cargarDatosEnJTable();
            } else {
                JOptionPane.showMessageDialog(null, "No se pudieron guardar los cambios.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void eliminarCursoSeleccionado() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int selectedRow = tablaCursos.getSelectedRow();
            if (selectedRow >= 0) {
                int idProducto = (int) tablaCursos.getValueAt(selectedRow, 0);

                int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de que deseas cancelar este curso?", "Confirmar cancelación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    Statement statement = conexion.createStatement();
                    String deleteQuery = "DELETE FROM cursos WHERE idcursos = " + idProducto;
                    int rowsDeleted = statement.executeUpdate(deleteQuery);

                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(null, "Curso eliminado exitosamente.");
                        cargarDatosEnJTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar el curso.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Container getPanel() {
        return mainPanel;
    }
}
