
package admin;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class usuarios {

    private JPanel mainPanel;
    private JButton clientesButton;
    private JButton irAPedidosButton;
    private JButton irAProductosButton;
    public usuarios() {
        clientesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Estudiantes clientesView = new Estudiantes();

                JFrame clientesFrame = new JFrame("Estudiantes");
                clientesFrame.setContentPane(clientesView.getPanel());
                clientesFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                clientesFrame.setSize(400, 600); // Establece el tamaño de la ventana
                clientesFrame.setVisible(true);
            }
        });

        irAPedidosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CursosPedidos pedidosView = new CursosPedidos();

                JFrame pedidosFrame = new JFrame("CursosPedidos");
                pedidosFrame.setContentPane(pedidosView.getPanel());
                pedidosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                pedidosFrame.setSize(400, 600); // Establece el tamaño de la ventana
                pedidosFrame.setVisible(true);
            }
        });

        irAProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cursos productosView = new Cursos();

                JFrame productosFrame = new JFrame("Cursos");
                productosFrame.setContentPane(productosView.getPanel());
                productosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                productosFrame.setSize(400, 600); // Establece el tamaño de la ventana
                productosFrame.setVisible(true);
            }
        });
    }


    public Container getPanel() {
        return mainPanel;
    }
}
