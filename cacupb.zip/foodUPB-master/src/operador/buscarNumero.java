package operador;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Clase que permite al usuario buscar un número de teléfono en la base de datos.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class buscarNumero {
    /**
     * Panel principal de la ventana.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el panel principal de la ventana.
    private JPanel panel1;

    /**
     * Campo de texto para ingresar el número de teléfono.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar el número de teléfono.
    private JTextField textField1;

    /**
     * Botón para buscar el número de teléfono.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para buscar el número de teléfono.
    private JButton buscarNumeroButton;

    /**
     * Método constructor que inicializa los componentes de la ventana.
     */
    // **Documentación del método:**
    // Este método inicializa los componentes de la ventana.
    public buscarNumero() {

        // **Documentación del bloque de código:**
        // Este bloque de código agrega un evento al botón "Buscar número".


        buscarNumeroButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String numeroBuscado = textField1.getText();

                String nombreEstudiante = obtenerNombreEstudiante(numeroBuscado);

                if (nombreEstudiante != null) {
                    JOptionPane.showMessageDialog(null,
                            "El número " + numeroBuscado + " pertenece a " + nombreEstudiante);
                    abrirVentanaRealizarPedido();

                } else {
                    JOptionPane.showMessageDialog(null, "El número " +
                            numeroBuscado + " no se encuentra en la base de datos.");
                    abrirVentanaRegistroUsuario();
                }
            }
        });
    }

    public JPanel getPanel() {
        return panel1;
    }

    private String obtenerNombreEstudiante(String numero) {
        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                String consulta = "SELECT nombre FROM estudiantes WHERE telefono = ?";
                PreparedStatement ps = conexion.prepareStatement(consulta);
                ps.setString(1, numero);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    String nombreEstudiante = rs.getString("nombre");
                    conexion.close();
                    return nombreEstudiante;
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al verificar el número en la base de datos: " + e.getMessage());
            }
        }

        return null;
    }

    private void abrirVentanaRealizarPedido() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(panel1);

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                realizarPedido pedidoView = new realizarPedido();
                JFrame newFrame = new JFrame("Realizar el curso");
                newFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                newFrame.setContentPane(pedidoView.getPanel());
                newFrame.pack();
                newFrame.setSize(900, 600);
                newFrame.setVisible(true);
            }
        });
    }

    private void abrirVentanaRegistroUsuario() {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(panel1);

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                registroUsuario registroUsuarioView = new registroUsuario();
                JFrame newFrame = new JFrame("Registro de estudiante");
                newFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                newFrame.setContentPane(registroUsuarioView.getPanelUsuario());
                newFrame.pack();
                newFrame.setSize(800, 500);
                newFrame.setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Buscar Número");
        frame.setContentPane(new buscarNumero().getPanel());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
