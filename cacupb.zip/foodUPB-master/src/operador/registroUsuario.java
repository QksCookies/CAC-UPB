package operador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import databaseConexion.dbConexion;
/**
 * Clase que permite al usuario registrarse.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class registroUsuario {
    /**
     * Campo de texto para ingresar el número de teléfono del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar el número de teléfono del usuario.
    private JTextField telefonoText;

    /**
     * Campo de texto para ingresar la identificación del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar la identificación del usuario.
    private JTextField idText;

    /**
     * Campo de texto para ingresar el nombre del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar el nombre del usuario.
    private JTextField nombreText;

    /**
     * Campo de texto para ingresar el apellido del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar el apellido del usuario.
    private JTextField apellidoText;

    /**
     * Campo de texto para ingresar el tipo de estudiante del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar el tipo de estudiante del usuario.
    private JTextField tipoEstudianteText;

    /**
     * Campo de texto para ingresar la fecha de cita del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar la fecha de cita del usuario.
    private JTextField fechaDeCitaText;

    /**
     * Campo de texto para ingresar la ciudad del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar la ciudad del usuario.
    private JTextField ciudadText;

    /**
     * Campo de texto para ingresar la dirección del usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el campo de texto para ingresar la dirección del usuario.
    private JTextField direccionText;

    /**
     * Botón para registrar al usuario.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para registrar al usuario.
    private JButton registrarClienteButton;

    /**
     * Panel principal de la ventana.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el panel principal de la ventana.
    private JPanel panelUsuario;

    /**
     * Botón para cerrar la ventana.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para cerrar la ventana.
    private JButton cerrarPaginaButton;

    /**
     * Constructor que inicializa los componentes de la ventana.
     */
    // **Documentación del método:**
    // Este método inicializa los componentes de la ventana.
    public registroUsuario() {
        registrarClienteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(idText.getText());
                String nombre = nombreText.getText();
                String numero = telefonoText.getText();
                String apellido = apellidoText.getText();
                String direccion = direccionText.getText();
                String tipo = tipoEstudianteText.getText();
                String ciudad = ciudadText.getText();
                String fecha = fechaDeCitaText.getText();

                Connection con = dbConexion.obtenerConexion();

                if (con != null) {
                    try {
                        String sql = "INSERT INTO estudiantes (idestudiantes, telefono, nombre, apellido, tipo_estudiante, fecha_de_cita, ciudad, direccion) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                        PreparedStatement statement = con.prepareStatement(sql);
                        statement.setString(1, String.valueOf(id));
                        statement.setString(2, numero);
                        statement.setString(3, nombre);
                        statement.setString(4, apellido);
                        statement.setString(5, tipo);
                        statement.setString(6, fecha);
                        statement.setString(7, ciudad);
                        statement.setString(8,direccion);

                        statement.executeUpdate();

                        idText.setText("");
                        telefonoText.setText("");
                        nombreText.setText("");
                        apellidoText.setText("");
                        tipoEstudianteText.setText("");
                        fechaDeCitaText.setText("");
                        ciudadText.setText("");
                        direccionText.setText("");

                        JOptionPane.showMessageDialog(null, "Estudiante registrado con éxito");

                        abrirVistaRealizarPedido();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Error al registrar el estudiante: " + ex.getMessage());
                    } finally {
                        try {
                            con.close();
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                }
            }
        });
        cerrarPaginaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Window window = SwingUtilities.getWindowAncestor(cerrarPaginaButton);

                if (window != null) {
                    ((Window) window).dispose();
                }
            }
        });

    }

    public JPanel getPanelUsuario() {
        return panelUsuario;
    }

    private void abrirVistaRealizarPedido() {
        JFrame currentFrame = (JFrame) SwingUtilities.getRoot(panelUsuario);

        if (currentFrame != null) {
            currentFrame.dispose();

            realizarPedido realizarPedidoView = new realizarPedido();
            JFrame frame = new JFrame("Realizar curso pedido");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setContentPane(realizarPedidoView.getPanel());
            frame.pack();
            frame.setSize(800, 400);
            frame.setVisible(true);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                JFrame frame = new JFrame("Registro de Usuario");
                registroUsuario registroUsuarioView = new registroUsuario();
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setContentPane(registroUsuarioView.getPanelUsuario());
                frame.pack();
                frame.setSize(800, 400);
                frame.setVisible(true);
            }
        });
    }
}
