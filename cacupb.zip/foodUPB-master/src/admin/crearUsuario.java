package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Clase que permite a los usuarios añadir nuevos usuarios a una base de datos.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class crearUsuario {
    /**
     * Botón para añadir el usuario a la base de datos.
     */
    private JButton añadirButton;

    /**
     * Campo de texto para ingresar el nombre de usuario.
     *
     * @see java.lang.String
     */
    private JTextField usuarioText;

    /**
     * Campo de texto para ingresar la contraseña del usuario.
     *
     * @see java.lang.String
     */
    private JTextField contraText;

    /**
     * Campo de texto para ingresar el tipo de usuario (admin, usuario, etc.).
     *
     * @see java.lang.String
     */
    private JTextField tipoText;

    /**
     * Panel principal que contiene todos los demás componentes de la GUI.
     *
     * @see javax.swing.JPanel
     */
    private JPanel mainPanel;

    /**
     * Constructor que inicializa todos los componentes de la GUI y agrega un listener al botón `añadirButton`.
     */
    public crearUsuario() {
        añadirButton = new JButton("Añadir usuario");
        usuarioText = new JTextField();
        contraText = new JTextField();
        tipoText = new JTextField();
        mainPanel = new JPanel();

        añadirButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    añadirUsuarioABaseDeDatos();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        mainPanel.add(usuarioText);
        mainPanel.add(contraText);
        mainPanel.add(tipoText);
        mainPanel.add(añadirButton);
    }

    /**
     * Añade el usuario a la base de datos.
     *
     * @throws SQLException Si se produce un error al conectarse a la base de datos o al insertar el usuario.
     */
    public void añadirUsuarioABaseDeDatos() throws SQLException {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            String usuario = usuarioText.getText();
            String tipoUsuario = tipoText.getText();
            String contrasena = contraText.getText();

            Statement statement = conexion.createStatement();
            String insertQuery = "INSERT INTO usuarios (usuario, tipo_usuario, contrasena) VALUES ('" + usuario + "', '" + tipoUsuario + "', '" + contrasena + "')";
            int rowsInserted = statement.executeUpdate(insertQuery);

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Usuario añadido exitosamente.");
                // Puedes limpiar los campos de texto después de añadir el usuario si lo deseas.
                usuarioText.setText("");
                tipoText.setText("");
                contraText.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo añadir el usuario.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Método principal que crea una ventana que permite a los usuarios añadir nuevos usuarios a una base de datos.
     *
     * @param args Los argumentos de la línea de comandos.
     */
    public static void main(String[] args) {
        JFrame frame = new JFrame("Crear Usuario");
        frame.setContentPane(new crearUsuario().mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    /**
     * Regresa el panel principal de la GUI.
     *
     * @return El panel principal de la GUI.
     */
    public Container getPanel() {
        return mainPanel;
    }
}