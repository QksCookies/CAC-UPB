package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Clase que permite a los usuarios gestionar los cursos pedidos de una base de datos.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class CursosPedidos {
    /**
     * Tabla que muestra los cursos pedidos de la base de datos.
     */
    private JTable tablaCursosPedidos;

    /**
     * Panel principal que contiene todos los demás componentes de la GUI.
     */
    private JPanel mainPanel;

    /**
     * Botón para eliminar el curso pedido seleccionado.
     */
    private JButton eliminarCursosPedidosButton;

    /**
     * Constructor que inicializa todos los componentes de la GUI y agrega un listener al botón para eliminar pedidos.
     */
    public CursosPedidos() {
        cargarDatosEnJTable();

        eliminarCursosPedidosButton.addActionListener(e -> eliminarPedidoSeleccionado());
    }

    /**
     * Carga los datos de los cursos pedidos de la base de datos en la tabla.
     */
    public void cargarDatosEnJTable() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID Curso");
        modelo.addColumn("Curso");
        modelo.addColumn("Estudiante");
        modelo.addColumn("Cantidad");

        try {
            Statement statement = conexion.createStatement();
            String query = "SELECT cursos_pedidos.idcursos_pedidos, cursos.nombre_curso, estudiantes.nombre, cursos_pedidos.cantidad FROM cursos_pedidos " +
                    "INNER JOIN cursos ON cursos_pedidos.idcursos = cursos.idcursos " +
                    "INNER JOIN estudiantes ON cursos_pedidos.idestudiantes = estudiantes.idestudiantes";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                modelo.addRow(new Object[]{
                        resultSet.getInt("idcursos_pedidos"),
                        resultSet.getString("nombre_curso"),
                        resultSet.getString("nombre"),
                        resultSet.getInt("cantidad")
                });
            }

            tablaCursosPedidos.setModel(modelo);
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Elimina el curso pedido seleccionado.
     */
    public void eliminarPedidoSeleccionado() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int selectedRow = tablaCursosPedidos.getSelectedRow();
            if (selectedRow >= 0) {
                int idcursos = (int) tablaCursosPedidos.getValueAt(selectedRow, 0);

                int confirmacion = JOptionPane.showConfirmDialog(null, "¿Estás seguro de que deseas cancelar este curso?", "Confirmar cancelación", JOptionPane.YES_NO_OPTION);

                if (confirmacion == JOptionPane.YES_OPTION) {
                    Statement statement = conexion.createStatement();
                    String deleteQuery = "DELETE FROM cursos_pedidos WHERE idcursos = " + idcursos;
                    int rowsDeleted = statement.executeUpdate(deleteQuery);

                    if (rowsDeleted > 0) {
                        JOptionPane.showMessageDialog(null, "Curso cancelado exitosamente.");
                        cargarDatosEnJTable();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se pudo cancelar el curso.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Container getPanel() {
        return mainPanel;
    }
}
