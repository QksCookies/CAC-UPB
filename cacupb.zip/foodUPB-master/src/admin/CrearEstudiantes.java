package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Clase que permite a los usuarios añadir nuevos estudiantes a una base de datos.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class CrearEstudiantes {
    /**
     * Botón para añadir el estudiante a la base de datos.
     */
    private JButton addEstudiantesButton;

    /**
     * Campo de texto para ingresar el teléfono del estudiante.
     */
    private JTextField telefonoText;

    /**
     * Campo de texto para ingresar el nombre del estudiante.
     */
    private JTextField nombreText;

    /**
     * Campo de texto para ingresar el apellido del estudiante.
     */
    private JTextField apellidoText;

    /**
     * Campo de texto para ingresar el tipo de estudiante (regular, profesional, etc.).
     */
    private JTextField tipoEstudianteText;

    /**
     * Campo de texto para ingresar la fecha de cita del estudiante.
     */
    private JTextField fechaDeCitaText;

    /**
     * Campo de texto para ingresar la ciudad del estudiante.
     */
    private JTextField ciudadText;

    /**
     * Campo de texto para ingresar la dirección del estudiante.
     */
    private JTextField direccionText;

    /**
     * Panel principal que contiene todos los demás componentes de la GUI.
     */
    private JPanel mainPanel;

    /**
     * Constructor que inicializa todos los componentes de la GUI y agrega un listener al botón `addEstudiantesButton`.
     */
    public CrearEstudiantes() {
        addEstudiantesButton = new JButton("Añadir estudiante");
        telefonoText = new JTextField();
        nombreText = new JTextField();
        apellidoText = new JTextField();
        tipoEstudianteText = new JTextField();
        fechaDeCitaText = new JTextField();
        ciudadText = new JTextField();
        direccionText = new JTextField();
        mainPanel = new JPanel();

        addEstudiantesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addEstudiantesABaseDeDatos();
            }
        });

        mainPanel.add(telefonoText);
        mainPanel.add(nombreText);
        mainPanel.add(apellidoText);
        mainPanel.add(tipoEstudianteText);
        mainPanel.add(fechaDeCitaText);
        mainPanel.add(ciudadText);
        mainPanel.add(direccionText);
        mainPanel.add(addEstudiantesButton);
    }

    /**
     * Añade el estudiante a la base de datos.
     */
    public void addEstudiantesABaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            int telefono = Integer.parseInt(telefonoText.getText());
            String nombre = nombreText.getText();
            String apellido = apellidoText.getText();
            String tipoEstudiante = tipoEstudianteText.getText();
            String fechaDeCita = fechaDeCitaText.getText();
            String ciudad = ciudadText.getText();
            String direccion = direccionText.getText();

            Statement statement = conexion.createStatement();
            String insertQuery = "INSERT INTO estudiantes (telefono, nombre, apellido, tipo_estudiante, fecha_de_cita, ciudad, direccion) " +
                    "VALUES ('" + telefono + "', '" + nombre + "', '" + apellido + "', '" + tipoEstudiante + "', '" + fechaDeCita + "', '" + ciudad + "', '" + direccion + "')";
            int rowsInserted = statement.executeUpdate(insertQuery);

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Estudiante añadido exitosamente.");

                telefonoText.setText("");
                nombreText.setText("");
                apellidoText.setText("");
                tipoEstudianteText.setText("");
                fechaDeCitaText.setText("");
                ciudadText.setText("");
                direccionText.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo añadir el estudiante.");
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public Container getPanel() {
        return mainPanel;
    }
}
