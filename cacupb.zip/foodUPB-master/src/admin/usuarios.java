
package admin;

import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Clase que representa la vista principal de la aplicación.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class usuarios {
    /**
     * Panel principal de la aplicación.
     */
    private JPanel mainPanel;

    /**
     * Botón para mostrar la vista de los clientes.
     */
    private JButton clientesButton;

    /**
     * Botón para mostrar la vista de los pedidos.
     */
    private JButton irAPedidosButton;

    /**
     * Botón para mostrar la vista de los productos.
     */
    private JButton irAProductosButton;

    /**
     * Constructor que inicializa los componentes de la vista.
     */
    public usuarios() {
        mainPanel = new JPanel();
        clientesButton = new JButton("Clientes");
        irAPedidosButton = new JButton("Pedidos");
        irAProductosButton = new JButton("Productos");

        mainPanel.add(clientesButton);
        mainPanel.add(irAPedidosButton);
        mainPanel.add(irAProductosButton);

        clientesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Estudiantes clientesView = new Estudiantes();

                JFrame clientesFrame = new JFrame("Estudiantes");
                clientesFrame.setContentPane(clientesView.getPanel());
                clientesFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                clientesFrame.setSize(400, 600); // Establece el tamaño de la ventana
                clientesFrame.setVisible(true);
            }
        });

        irAPedidosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                CursosPedidos pedidosView = new CursosPedidos();

                JFrame pedidosFrame = new JFrame("CursosPedidos");
                pedidosFrame.setContentPane(pedidosView.getPanel());
                pedidosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                pedidosFrame.setSize(400, 600); // Establece el tamaño de la ventana
                pedidosFrame.setVisible(true);
            }
        });

        irAProductosButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Cursos productosView = new Cursos();

                JFrame productosFrame = new JFrame("Cursos");
                productosFrame.setContentPane(productosView.getPanel());
                productosFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE); // Cerrar solo esta ventana al salir
                productosFrame.setSize(400, 600); // Establece el tamaño de la ventana
                productosFrame.setVisible(true);
            }
        });
    }

    /**
     * Regresa el panel principal de la vista.
     *
     * @return El panel principal de la vista.
     */
    public Container getPanel() {
        return mainPanel;
    }
}
