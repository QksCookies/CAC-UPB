package admin;

import databaseConexion.dbConexion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Clase que permite a los usuarios añadir nuevos cursos a una base de datos.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class CrearCurso {
    /**
     * Campo de texto para ingresar el nombre del curso.
     */
    private JTextField nombreText;

    /**
     * Campo de texto para ingresar el valor del curso.
     */
    private JTextField valorText;

    /**
     * Botón para añadir el curso a la base de datos.
     */
    private JButton addCursoButton;

    /**
     * Panel principal que contiene todos los demás componentes de la GUI.
     */
    private JPanel mainPanel;

    /**
     * Constructor que inicializa todos los componentes de la GUI y agrega un listener al botón `addCursoButton`.
     */
    public CrearCurso() {
        nombreText = new JTextField();
        valorText = new JTextField();
        addCursoButton = new JButton("Añadir curso");
        mainPanel = new JPanel();

        addCursoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addCursoABaseDeDatos();
            }
        });

        mainPanel.add(nombreText);
        mainPanel.add(valorText);
        mainPanel.add(addCursoButton);
    }

    /**
     * Añade el curso a la base de datos.
     */
    public void addCursoABaseDeDatos() {
        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            String nombre = nombreText.getText();
            double valor = Double.parseDouble(valorText.getText());

            Statement statement = conexion.createStatement();
            String insertQuery = "INSERT INTO cursos (nombre_curso, valor_curso) " +
                    "VALUES ('" + nombre + "', " + valor + ")";
            int rowsInserted = statement.executeUpdate(insertQuery);

            if (rowsInserted > 0) {
                JOptionPane.showMessageDialog(null, "Curso añadido exitosamente.");
                nombreText.setText("");
                valorText.setText("");
            } else {
                JOptionPane.showMessageDialog(null, "No se pudo añadir el curso.");
            }
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Regresa el panel principal de la GUI.
     *
     * @return El panel principal de la GUI.
     */
    public Container getPanel() {
        return mainPanel;
    }
}
