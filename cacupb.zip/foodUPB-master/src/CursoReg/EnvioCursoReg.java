package CursoReg;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import Estructuras.ColaBancos;
import databaseConexion.dbConexion;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Clase que muestra los pedidos de la cola de cocina y permite al usuario marcarlos como entregados.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class EnvioCursoReg {
    /**
     * Área de texto para mostrar la información del pedido seleccionado.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el área de texto para mostrar la información del pedido seleccionado.
    private JTextArea textArea1;

    /**
     * Tabla para mostrar los pedidos de la cola de cocina.
     */
    // **Documentación del atributo:**
    // Este atributo almacena la tabla para mostrar los pedidos de la cola de cocina.
    private JTable table1;

    /**
     * Botón para ver la información del pedido seleccionado.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para ver la información del pedido seleccionado.
    private JButton verInformacionButton;

    /**
     * Panel principal de la ventana.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el panel principal de la ventana.
    private JPanel jpanel1;

    /**
     * Botón para marcar el pedido seleccionado como entregado.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para marcar el pedido seleccionado como entregado.
    private JButton pedidoEntregadoButton;

    /**
     * Botón para recargar la tabla de pedidos.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para recargar la tabla de pedidos.
    private JButton recargarPaginaButton;

    /**
     * Cola de bancos que contiene los pedidos de la cocina.
     */
    // **Documentación del atributo:**
    // Este atributo almacena la cola de bancos que contiene los pedidos de la cocina.
    private ColaBancos colaCocina;

    /**
     * Constructor que inicializa los componentes de la ventana.
     */
    // **Documentación del método:**
    // Este método inicializa los componentes de la ventana.
    public EnvioCursoReg() {
        cargarPedidosEnColaCocina();
        cargarPedidosEnTablaCocina();

        verInformacionButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarInfoPedidoEnTextArea();
            }
        });

        pedidoEntregadoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarPedidoSeleccionado();
            }
        });
        recargarPaginaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                recargarPedidosEnTablaCocina();
            }
        });
    }

    public void recargarPedidosEnTablaCocina() {
        DefaultTableModel modelo = (DefaultTableModel) table1.getModel();
        modelo.setRowCount(0); // Borra todos los datos actuales de la tabla

        cargarPedidosEnColaCocina(); // Carga nuevamente los pedidos en la cola
        cargarPedidosEnTablaCocina(); // Carga los pedidos en la tabla

        // Puedes mostrar un mensaje de éxito si lo deseas
        JOptionPane.showMessageDialog(jpanel1, "La página se ha recargado exitosamente.");
    }


    public void cargarPedidosEnColaCocina() {
        colaCocina = new ColaBancos(10);

        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            Statement statement = conexion.createStatement();
            String query = "SELECT idcursos_pedidos, tipo_estudiante, tipo_pedido FROM cursos_pedidos p " +
                    "JOIN estudiantes c ON p.idestudiantes = c.idestudiantes";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int idPedido = resultSet.getInt("idcursos_pedidos");
                int tipoCliente = resultSet.getInt("tipo_estudiante");
                String tipoPedido = resultSet.getString("tipo_pedido");
                int tiempoCoccion;

                if ("rapido".equals(tipoPedido)) {
                    tiempoCoccion = 1 + (int)(Math.random() * 5);
                } else {
                    tiempoCoccion = 6 + (int)(Math.random() * 10);
                }

                if (tipoCliente == 1) {
                    colaCocina.insertar(idPedido, 1, tiempoCoccion);
                } else {
                    colaCocina.insertar(idPedido, 2, tiempoCoccion);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void cargarPedidosEnTablaCocina() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID Pedido");
        modelo.addColumn("Prioridad");
        modelo.addColumn("Tiempo de Cocción");
        modelo.addColumn("Tipo de Pedido");
        modelo.addColumn("Cursos");
        modelo.addColumn("Estudiante");

        ColaBancos.Pedido pedido = colaCocina.extraer();

        while (pedido != null) {
            Connection conexion = dbConexion.obtenerConexion();
            try {
                PreparedStatement ps = conexion.prepareStatement(
                        "SELECT p.idcursos_pedidos, c.tipo_estudiante, p.tipo_pedido, pr.nombre_curso, c.nombre " +
                                "FROM cursos_pedidos p " +
                                "JOIN cursos pr ON p.idcursos = pr.idcursos " +
                                "JOIN estudiantes c ON p.idestudiantes = c.idestudiantes " +
                                "WHERE p.idcursos_pedidos = ?"
                );
                ps.setInt(1, pedido.numero);

                ResultSet resultSet = ps.executeQuery();

                if (resultSet.next()) {
                    String tipoPedido = resultSet.getString("tipo_pedido");
                    String producto = resultSet.getString("nombre_curso");
                    String cliente = resultSet.getString("nombre");

                    modelo.addRow(new Object[]{
                            pedido.numero,
                            pedido.prioridad,
                            pedido.tiempoCoccion,
                            tipoPedido,
                            producto,
                            cliente
                    });
                }
                resultSet.close();
                ps.close();
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            pedido = colaCocina.extraer();
        }

        table1.setModel(modelo);
    }

    public void mostrarInfoPedidoEnTextArea() {
        DefaultTableModel modelo = (DefaultTableModel) table1.getModel();
        int filaSeleccionada = table1.getSelectedRow();

        if (filaSeleccionada >= 0) {
            int idPedido = (int) modelo.getValueAt(filaSeleccionada, 0);
            double valorTotal = calcularValorTotalDelPedido(idPedido);
            String cliente = modelo.getValueAt(filaSeleccionada, 5).toString();
            String producto = modelo.getValueAt(filaSeleccionada, 4).toString();
            int tiempoCoccion = (int) modelo.getValueAt(filaSeleccionada, 2);
           
            String direccion = obtenerDireccionCliente(idPedido); // Obtener la dirección del cliente
            String barrio = obtenerBarrioCliente(idPedido); // Obtener el barrio del cliente
            String Municipio = obtenerMunicipiodelCliente(idPedido);
            String infoPedido = "Estudiante: " + cliente + "\n";
            infoPedido += "Curso tomado: " + producto + "\n";
            infoPedido += "Valor Total: $" + valorTotal + "\n";

            infoPedido += "Fecha del curso: " + direccion + "\n"; // Mostrar la dirección
            infoPedido += "curso tomado: " + barrio + "\n"; // Mostrar el barrio
            infoPedido += "direccion: " + Municipio + "\n"; // Mostrar el municipio
            textArea1.setText(infoPedido);
        } else {
            textArea1.setText("Por favor, selecciona un pedido del curso en la tabla.");
        }
    }




    private double calcularValorTotalDelPedido(int idPedido) {
        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                PreparedStatement ps = conexion.prepareStatement(
                        "SELECT total FROM cursos_pedidos WHERE idcursos_pedidos = ?"
                );
                ps.setInt(1, idPedido);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    double valorTotal = rs.getDouble("total");
                    conexion.close();
                    return valorTotal;
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al calcular el valor total del pedido: " + e.getMessage());
            }
        }

        return 0.0;
    }

    private void eliminarPedidoSeleccionado() {
        DefaultTableModel modelo = (DefaultTableModel) table1.getModel();
        int filaSeleccionada = table1.getSelectedRow();

        if (filaSeleccionada >= 0) {
            int idPedido = (int) modelo.getValueAt(filaSeleccionada, 0);

            eliminarPedidoDeLaBaseDeDatos(idPedido);
            modelo.removeRow(filaSeleccionada);
            textArea1.setText("");
        } else {
            textArea1.setText("Por favor, selecciona un pedido en la tabla.");
        }
    }
    private String obtenerDireccionCliente(int idPedido) {
        Connection conexion = dbConexion.obtenerConexion();
        String direccion = "";

        if (conexion != null) {
            try {
                PreparedStatement ps = conexion.prepareStatement(
                        "SELECT c.direccion " +
                                "FROM pedido p " +
                                "JOIN clientes c ON p.idclientes = c.idclientes " +
                                "WHERE p.idpedido = ?"
                );
                ps.setInt(1, idPedido);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    direccion = rs.getString("direccion");
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al obtener la dirección del cliente: " + e.getMessage());
            }
        }

        return direccion;
    }
    private String obtenerMunicipiodelCliente(int idPedido) {
        Connection conexion = dbConexion.obtenerConexion();
        String direccion = "";

        if (conexion != null) {
            try {
                PreparedStatement ps = conexion.prepareStatement(
                        "SELECT c.ciudad " +
                                "FROM cursos_pedidos p " +
                                "JOIN estudiantes c ON p.idestudiantes = c.idestudiantes " +
                                "WHERE p.idcursos_pedidos = ?"
                );
                ps.setInt(1, idPedido);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    direccion = rs.getString("ciudad");
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al obtener la dirección del estudiante: " + e.getMessage());
            }
        }

        return direccion;
    }
    private String obtenerBarrioCliente(int idPedido) {
        Connection conexion = dbConexion.obtenerConexion();
        String barrio = "";

        if (conexion != null) {
            try {
                PreparedStatement ps = conexion.prepareStatement(
                        "SELECT c.ciudad " +
                                "FROM cursos_pedidos p " +
                                "JOIN estudiantes c ON p.idestudiantes = c.idestudiantes " +
                                "WHERE p.idcursos_pedidos = ?"
                );
                ps.setInt(1, idPedido);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    barrio = rs.getString("ciudad");
                }

                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al obtener la ciudad del estudiante: " + e.getMessage());
            }
        }

        return barrio;
    }

    private void eliminarPedidoDeLaBaseDeDatos(int idPedido) {
        Connection conexion = dbConexion.obtenerConexion();

        if (conexion != null) {
            try {
                PreparedStatement ps = conexion.prepareStatement(
                        "DELETE FROM cursos_pedidos WHERE idcursos_pedidos = ?"
                );
                ps.setInt(1, idPedido);
                ps.executeUpdate();
                conexion.close();
            } catch (SQLException e) {
                System.err.println("Error al cancelar el curso pedido de la base de datos: " + e.getMessage());
            }
        }
    }

    public JPanel getPanel1() {
        return jpanel1;
    }
}
