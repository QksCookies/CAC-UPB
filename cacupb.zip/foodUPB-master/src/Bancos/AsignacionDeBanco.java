package Bancos;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import databaseConexion.dbConexion; // Importa la clase de conexión a la base de datos
import Estructuras.ColaBancos; // Importa la clase de la cola de cocina
/**
 * Clase que asigna los pedidos a los bancos.
 *
 * @author Juliana Chávez King
 * @author Fernando Javier Vega Sabino
 * @author Sergio David Mesa Puerto
 * @since 2023-10-25
 */
public class AsignacionDeBanco {

    /**
     * Tabla que muestra los pedidos de la cola de bancos.
     */
    // **Documentación del atributo:**
    // Este atributo almacena la tabla que muestra los pedidos de la cola de bancos.
    private JTable tablaBancos;

    /**
     * Panel principal de la vista.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el panel principal de la vista.
    private JPanel mainPanel;

    /**
     * Botón para marcar un pedido como listo.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para marcar un pedido como listo.
    private JButton marcarComoListoButton;

    /**
     * Botón para recargar la página.
     */
    // **Documentación del atributo:**
    // Este atributo almacena el botón para recargar la página.
    private JButton recargarPaginaButton;

    /**
     * Constructor que inicializa los componentes de la vista.
     */
    // **Documentación del método:**
    // Este método inicializa los componentes de la vista.
    public AsignacionDeBanco() {
        cargarPedidosEnColaCocina();

        cargarPedidosEnTablaCocina();

        marcarComoListoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                marcarPedidoComoListo();
            }
        });
    }

    private void marcarPedidoComoListo() {
        int filaSeleccionada = tablaBancos.getSelectedRow();
        if (filaSeleccionada == -1) {
            JOptionPane.showMessageDialog(mainPanel, "Por favor, selecciona un curso de la tabla.");
            return;
        }

        int idcursos_pedidos = (int) tablaBancos.getValueAt(filaSeleccionada, 0); // Suponiendo que la columna 0 contiene el ID del pedido.

        DefaultTableModel modelo = (DefaultTableModel) tablaBancos.getModel();
        modelo.removeRow(filaSeleccionada);
    }

    public void cargarPedidosEnColaCocina() {
        ColaBancos colaBancos = new ColaBancos(10);

        Connection conexion = dbConexion.obtenerConexion();
        if (conexion == null) {
            return;
        }

        try {
            Statement statement = conexion.createStatement();
            String query = "SELECT idcursos_pedidos, tipo_estudiante, tipo_pedido FROM curso_pedido p " +
                    "JOIN estudiantes c ON p.idclientes = c.idestudiantes";
            ResultSet resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int idPedido = resultSet.getInt("idcursos_pedidos");
                int tipoCliente = resultSet.getInt("tipo_cliente");
                String tipoPedido = resultSet.getString("tipo_pedido");
                int tiempoCoccion;

                // Asigna el tiempo de cocción según el tipo de pedido
                if ("rapido".equals(tipoPedido)) {
                    tiempoCoccion = 1 + (int)(Math.random() * 5); // Entre 1 y 5 minutos
                } else {
                    tiempoCoccion = 6 + (int)(Math.random() * 10); // Superior a 5 minutos
                }

                if (tipoCliente == 1) {
                    colaBancos.insertar(idPedido, 1, tiempoCoccion); // Prioridad 1 para clientes premium
                } else {
                    colaBancos.insertar(idPedido, 2, tiempoCoccion); // Prioridad 2 para clientes normales
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                conexion.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        recargarPaginaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                recargarPedidosEnTablaCocina();
            }
        });

    }

    public void recargarPedidosEnTablaCocina() {
        DefaultTableModel modelo = (DefaultTableModel) tablaBancos.getModel();
        modelo.setRowCount(0); // Borra todos los datos actuales de la tabla

        cargarPedidosEnColaCocina();
        cargarPedidosEnTablaCocina();

        JOptionPane.showMessageDialog(mainPanel, "La página se ha recargado exitosamente.");
    }


    public void cargarPedidosEnTablaCocina() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID Pedido");
        modelo.addColumn("Prioridad");
        modelo.addColumn("Tiempo de Cocción");
        modelo.addColumn("Tipo de Pedido");
        modelo.addColumn("Producto");
        modelo.addColumn("Cliente");

        ColaBancos.Pedido pedido = ColaBancos.extraer();
        Connection conexion = dbConexion.obtenerConexion();

        while (pedido != null) {
            try {
                Statement statement = conexion.createStatement();
                String query = "SELECT p.idcursos_pedidos, c.tipo_estudiante, p.tipo_pedido, pr.nombre_curso, c.nombre " +
                        "FROM cursos_pedidos p " +
                        "JOIN cursos pr ON p.idcursos = pr.idcursos " +
                        "JOIN estudiantes c ON p.idestudiantes = c.idestudiantes " +
                        "WHERE p.idcursos_pedidos = " + pedido.numero;

                ResultSet resultSet = statement.executeQuery(query);

                if (resultSet.next()) {
                    String tipoPedido = resultSet.getString("tipo_pedido");
                    String producto = resultSet.getString("nombre_curso");
                    String cliente = resultSet.getString("nombre");

                    modelo.addRow(new Object[] {
                            pedido.numero,
                            pedido.prioridad,
                            pedido.tiempoCoccion,
                            tipoPedido,
                            producto,
                            cliente
                    });
                }
                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }

            pedido = ColaBancos.extraer();
        }

        tablaBancos.setModel(modelo);
    }


    public JPanel getMainPanel() {
        return mainPanel;
    }
}
